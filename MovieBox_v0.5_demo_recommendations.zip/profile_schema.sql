-- MovieBox v0.5 profile, list, contact/chat schema.
-- Run after the original user table exists. The server also creates these tables lazily.
ALTER TABLE user ADD COLUMN display_name VARCHAR(100) NULL;
ALTER TABLE user ADD COLUMN description VARCHAR(500) NOT NULL DEFAULT '';

CREATE TABLE IF NOT EXISTS user_movie (
  email VARCHAR(255) NOT NULL,
  movie_id VARCHAR(64) NOT NULL,
  title VARCHAR(255) NOT NULL,
  year VARCHAR(16), genre VARCHAR(100), poster_url TEXT,
  list_type ENUM('favorite','watchlist') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (email, movie_id, list_type),
  CONSTRAINT fk_user_movie_user FOREIGN KEY (email) REFERENCES user(email) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS conversation (
  conversation_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120), is_group BOOLEAN NOT NULL DEFAULT FALSE,
  created_by VARCHAR(255) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_conversation_creator FOREIGN KEY (created_by) REFERENCES user(email) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS conversation_member (
  conversation_id BIGINT NOT NULL, email VARCHAR(255) NOT NULL,
  joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (conversation_id, email),
  CONSTRAINT fk_member_conversation FOREIGN KEY (conversation_id) REFERENCES conversation(conversation_id) ON DELETE CASCADE,
  CONSTRAINT fk_member_user FOREIGN KEY (email) REFERENCES user(email) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS message (
  message_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  conversation_id BIGINT NOT NULL, sender_email VARCHAR(255) NOT NULL,
  body TEXT NOT NULL, sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_message_conversation FOREIGN KEY (conversation_id) REFERENCES conversation(conversation_id) ON DELETE CASCADE,
  CONSTRAINT fk_message_sender FOREIGN KEY (sender_email) REFERENCES user(email) ON DELETE CASCADE
);

-- Movie tastes used to rank profile recommendations.
CREATE TABLE IF NOT EXISTS user_taste (
  email VARCHAR(255) NOT NULL,
  genre VARCHAR(50) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (email, genre),
  CONSTRAINT fk_user_taste_user FOREIGN KEY (email) REFERENCES user(email) ON DELETE CASCADE
);
