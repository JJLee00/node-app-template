require('dotenv').config();
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

const demoUsers = [
  ['maya.chen@moviebox.demo','Maya Chen','Sci-fi dreamer, animation fan, and midnight-movie regular.',['Sci-Fi','Animation','Adventure']],
  ['jordan.lee@moviebox.demo','Jordan Lee','Thrillers, mysteries, and neo-noir are always at the top of my list.',['Thriller','Mystery','Neo-noir']],
  ['sofia.reyes@moviebox.demo','Sofia Reyes','I love character-driven dramas, romances, and documentaries.',['Drama','Romance','Documentary']],
  ['noah.williams@moviebox.demo','Noah Williams','Horror nights, sharp comedies, and cult classics.',['Horror','Comedy','Classics']],
  ['priya.patel@moviebox.demo','Priya Patel','Adventure, mystery, and science fiction fan.',['Adventure','Mystery','Sci-Fi']],
  ['ethan.brooks@moviebox.demo','Ethan Brooks','Classic films, drama, and thoughtful documentaries.',['Classics','Drama','Documentary']]
];

async function main(){
  const db=await mysql.createConnection({host:process.env.DB_HOST,user:process.env.DB_USER,password:process.env.DB_PASSWORD,database:process.env.DB_NAME});
  try{
    const [dc]=await db.execute("SHOW COLUMNS FROM user LIKE 'display_name'"); if(!dc.length) await db.execute("ALTER TABLE user ADD COLUMN display_name VARCHAR(100) NULL");
    const [desc]=await db.execute("SHOW COLUMNS FROM user LIKE 'description'"); if(!desc.length) await db.execute("ALTER TABLE user ADD COLUMN description VARCHAR(500) NOT NULL DEFAULT ''");
    await db.execute(`CREATE TABLE IF NOT EXISTS user_taste (email VARCHAR(255) NOT NULL,genre VARCHAR(50) NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(email,genre),FOREIGN KEY(email) REFERENCES user(email) ON DELETE CASCADE)`);
    await db.execute(`CREATE TABLE IF NOT EXISTS social_movie (id INT NOT NULL AUTO_INCREMENT,tmdb_id INT NOT NULL,title VARCHAR(255) NOT NULL,release_date DATE NULL,poster_url VARCHAR(500) NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_social_movie_tmdb(tmdb_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    await db.execute(`CREATE TABLE IF NOT EXISTS social_review (id INT NOT NULL AUTO_INCREMENT,social_movie_id INT NOT NULL,reviewer_email VARCHAR(255) NOT NULL,rating TINYINT NOT NULL,review_text TEXT NOT NULL,visibility ENUM('Public','Private') NOT NULL DEFAULT 'Public',created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_social_review_movie(social_movie_id),KEY idx_social_review_reviewer(reviewer_email),FOREIGN KEY(social_movie_id) REFERENCES social_movie(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    const hash=await bcrypt.hash('Demo123!',10);
    for(const [email,name,description,tastes] of demoUsers){
      await db.execute(`INSERT INTO user(email,password,display_name,description) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE password=VALUES(password),display_name=VALUES(display_name),description=VALUES(description)`,[email,hash,name,description]);
      await db.execute('DELETE FROM user_taste WHERE email=?',[email]);
      for(const genre of tastes) await db.execute('INSERT INTO user_taste(email,genre) VALUES(?,?)',[email,genre]);
    }
    const movies=[
      [603,'The Matrix','1999-03-31'],[27205,'Inception','2010-07-16'],[807,'Se7en','1995-09-22'],
      [13,'Forrest Gump','1994-07-06'],[862,'Toy Story','1995-11-22'],[539,'Psycho','1960-09-08']
    ];
    const ids={};
    for(const [tmdb,title,date] of movies){await db.execute(`INSERT INTO social_movie(tmdb_id,title,release_date) VALUES(?,?,?) ON DUPLICATE KEY UPDATE title=VALUES(title),release_date=VALUES(release_date)`,[tmdb,title,date]);const [r]=await db.execute('SELECT id FROM social_movie WHERE tmdb_id=?',[tmdb]);ids[tmdb]=r[0].id;}
    const emails=demoUsers.map(x=>x[0]); await db.query('DELETE FROM social_review WHERE reviewer_email IN (?)',[emails]);
    const reviews=[
      ['maya.chen@moviebox.demo',603,5,'A stylish sci-fi classic that still feels inventive.'],
      ['maya.chen@moviebox.demo',862,4,'Warm, funny, and endlessly rewatchable.'],
      ['jordan.lee@moviebox.demo',807,5,'A tense mystery with unforgettable atmosphere.'],
      ['sofia.reyes@moviebox.demo',13,4,'A moving character story with memorable performances.'],
      ['noah.williams@moviebox.demo',539,5,'Still one of the most effective suspense films.'],
      ['priya.patel@moviebox.demo',27205,5,'Big ideas and adventure executed with confidence.'],
      ['ethan.brooks@moviebox.demo',13,4,'An accessible drama with plenty to discuss.']
    ];
    for(const [email,tmdb,rating,text] of reviews) await db.execute('INSERT INTO social_review(social_movie_id,reviewer_email,rating,review_text,visibility) VALUES(?,?,?,?,\'Public\')',[ids[tmdb],email,rating,text]);
    console.log('Demo data loaded. Demo password for all seeded users: Demo123!');
  } finally { await db.end(); }
}
main().catch(e=>{console.error(e);process.exit(1);});
